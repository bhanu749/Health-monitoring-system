import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report
from sklearn.preprocessing import LabelEncoder
import joblib

# Load dataset
df = pd.read_csv("health_dataset_3000.csv")

# Features and target
X = df[["HeartRate", "SpO2", "Temperature_C", "Systolic", "Diastolic", "Fall"]]
y = df["HealthStatus"]

# Convert output labels (Normal / Abnormal → 0 / 1)
le = LabelEncoder()
y = le.fit_transform(y)

# Split data (80% training, 20% testing)
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# Create Random Forest model
model = RandomForestClassifier(
    n_estimators=100,
    max_depth=10,
    random_state=42
)

# Train model
model.fit(X_train, y_train)

# Predictions
y_pred = model.predict(X_test)

# Accuracy
accuracy = accuracy_score(y_test, y_pred)
print("Accuracy:", accuracy)

# Detailed report
print("\nClassification Report:\n")
print(classification_report(y_test, y_pred))

# Save model
joblib.dump(model, "health_model_rf.pkl")
joblib.dump(le, "label_encoder.pkl")

print("\nModel saved as health_model_rf.pkl")
