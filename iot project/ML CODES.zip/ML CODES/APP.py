from flask import Flask, request, render_template_string
import numpy as np
import joblib
import requests

app = Flask(__name__)

# Load model and label encoder
model = joblib.load("health_model_rf.pkl")
le = joblib.load("label_encoder.pkl")

# ThingSpeak details (EDIT THIS)
CHANNEL_ID = "YOUR_CHANNEL_ID"
READ_API_KEY = "YOUR_READ_API_KEY"

# HTML UI (ALL IN ONE FILE)
html_page = """
<!DOCTYPE html>
<html>
<head>
    <title>Health Monitoring System</title>
    <style>
        body {
            font-family: Arial;
            background: linear-gradient(to right, #74ebd5, #ACB6E5);
            text-align: center;
            padding: 30px;
        }
        .container {
            background: white;
            padding: 25px;
            border-radius: 15px;
            width: 400px;
            margin: auto;
            box-shadow: 0 0 15px rgba(0,0,0,0.2);
        }
        input {
            width: 90%;
            padding: 10px;
            margin: 8px;
            border-radius: 8px;
            border: 1px solid #ccc;
        }
        button {
            padding: 12px;
            margin: 10px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 16px;
        }
        .manual-btn { background: #28a745; color: white; }
        .auto-btn { background: #007bff; color: white; }
        .result {
            font-size: 20px;
            margin-top: 15px;
            font-weight: bold;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Health Monitoring System</h2>

    <form method="POST">
        <input type="number" name="hr" placeholder="Heart Rate" required>
        <input type="number" name="spo2" placeholder="SpO2" required>
        <input type="number" step="0.1" name="temp" placeholder="Temperature (°C)" required>
        <input type="number" name="sys" placeholder="Systolic BP" required>
        <input type="number" name="dia" placeholder="Diastolic BP" required>
        <input type="number" name="fall" placeholder="Fall (0 or 1)" required>

        <button class="manual-btn" name="action" value="manual">Predict Manually</button>
        <button class="auto-btn" name="action" value="auto">Auto (ThingSpeak)</button>
    </form>

    {% if result %}
        <div class="result">
            Status: {{ result }}
        </div>
    {% endif %}

</div>

</body>
</html>
"""

# Function to predict
def predict(values):
    arr = np.array([values])
    pred = model.predict(arr)
    return le.inverse_transform(pred)[0]

# Fetch data from ThingSpeak
def get_thingspeak_data():
    url = f"https://api.thingspeak.com/channels/{CHANNEL_ID}/feeds/last.json?api_key={READ_API_KEY}"
    response = requests.get(url)
    data = response.json()

    return [
        float(data["field1"]),  # Heart Rate
        float(data["field2"]),  # SpO2
        float(data["field3"]),  # Temp
        float(data["field4"]),  # Systolic
        float(data["field5"]),  # Diastolic
        int(data["field6"])     # Fall
    ]

@app.route("/", methods=["GET", "POST"])
def home():
    result = None

    if request.method == "POST":
        action = request.form["action"]

        if action == "manual":
            values = [
                float(request.form["hr"]),
                float(request.form["spo2"]),
                float(request.form["temp"]),
                float(request.form["sys"]),
                float(request.form["dia"]),
                int(request.form["fall"])
            ]

        elif action == "auto":
            values = get_thingspeak_data()

        result = predict(values)

    return render_template_string(html_page, result=result)

if __name__ == "__main__":
    app.run(debug=False)
