import pandas as pd
import numpy as np

# Number of rows
num_rows = 3000

data = []

for _ in range(num_rows):
    # Generate realistic ranges
    heart_rate = np.random.randint(50, 130)        # bpm
    spo2 = np.random.randint(85, 100)              # %
    temp = round(np.random.uniform(35.0, 40.0), 1) # °C
    systolic = np.random.randint(90, 180)          # mmHg
    diastolic = np.random.randint(60, 120)         # mmHg
    fall = np.random.choice([0, 1], p=[0.85, 0.15]) # Mostly no fall

    # Define abnormal conditions
    abnormal = (
        heart_rate < 60 or heart_rate > 100 or
        spo2 < 95 or
        temp < 36.0 or temp > 38.5 or
        systolic < 90 or systolic > 140 or
        diastolic < 60 or diastolic > 90 or
        fall == 1
    )

    health_status = "Abnormal" if abnormal else "Normal"

    data.append([
        heart_rate, spo2, temp,
        systolic, diastolic,
        fall, health_status
    ])

# Create DataFrame
df = pd.DataFrame(data, columns=[
    "HeartRate", "SpO2", "Temperature_C",
    "Systolic", "Diastolic",
    "Fall", "HealthStatus"
])

# Save to CSV
df.to_csv("health_dataset_3000.csv", index=False)

print("Dataset generated successfully: health_dataset_3000.csv")
